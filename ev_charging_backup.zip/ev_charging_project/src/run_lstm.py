import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import os

# --- Config ---
SEQ_LENGTH = 24
BATCH_SIZE = 64
EPOCHS = 50
LEARNING_RATE = 0.001
HIDDEN_SIZE = 64
NUM_LAYERS = 2
DATA_DIR = 'ev_charging_project/data'
OUTPUT_DIR = 'ev_charging_project/figures'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# --- Data Prep ---
def prepare_dataset():
    print("Loading Data...")
    # Hourly Load
    df_hourly = pd.read_csv(os.path.join(DATA_DIR, 'Dataset_2_Hourly_EV_per_user.csv'), sep=';', decimal=',')
    df_hourly['datetime'] = pd.to_datetime(df_hourly['date_from'], format='%d.%m.%Y %H:%M')
    load_cols = [c for c in df_hourly.columns if 'kW' in c]
    df_hourly[load_cols] = df_hourly[load_cols].fillna(0)
    df_hourly['total_load'] = df_hourly[load_cols].sum(axis=1)
    df_main = df_hourly[['datetime', 'total_load']]

    # Traffic
    df_traffic = pd.read_csv(os.path.join(DATA_DIR, 'Dataset 6_Local traffic distribution.csv'), sep=';', decimal=',')
    df_traffic['datetime'] = pd.to_datetime(df_traffic['Date_from'], format='%d.%m.%Y %H:%M')
    traffic_cols = df_traffic.select_dtypes(include=[np.number]).columns
    df_traffic['total_traffic'] = df_traffic[traffic_cols].sum(axis=1)
    df_main = pd.merge(df_main, df_traffic[['datetime', 'total_traffic']], on='datetime', how='left').fillna(0)

    # Weather
    df_weather = pd.read_csv(os.path.join(DATA_DIR, 'Norway_Trondheim_ExactLoc_Weather.csv'))
    df_weather['date'] = pd.to_datetime(df_weather['datetime']).dt.date
    df_main['date'] = df_main['datetime'].dt.date
    df_main = pd.merge(df_main, df_weather[['date', 'temp', 'solar_rad']], on='date', how='left').fillna(0)

    # Cyclical Time Features
    df_main['hour_sin'] = np.sin(2 * np.pi * df_main['datetime'].dt.hour / 24)
    df_main['hour_cos'] = np.cos(2 * np.pi * df_main['datetime'].dt.hour / 24)
    
    df_main = df_main.sort_values('datetime').reset_index(drop=True)
    features = ['total_load', 'total_traffic', 'temp', 'solar_rad', 'hour_sin', 'hour_cos']
    return df_main, features

# --- Model ---
class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size=1):
        super(LSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        out, _ = self.lstm(x, (h0, c0))
        out = self.fc(out[:, -1, :])
        return out

# --- Main ---
print("Preparing Data...")
df, features = prepare_dataset()

# Split & Scale
train_size = int(len(df) * 0.8)
train_df, test_df = df.iloc[:train_size], df.iloc[train_size:]
scaler = MinMaxScaler()
train_scaled = scaler.fit_transform(train_df[features])
test_scaled = scaler.transform(test_df[features])

# Sequences
def create_sequences(data, seq_length):
    xs, ys = [], []
    for i in range(len(data) - seq_length):
        x = data[i:i+seq_length]
        y = data[i+seq_length][0] 
        xs.append(x)
        ys.append(y)
    return np.array(xs), np.array(ys)

print("Creating Sequences...")
X_train, y_train = create_sequences(train_scaled, SEQ_LENGTH)
X_test, y_test = create_sequences(test_scaled, SEQ_LENGTH)

train_loader = DataLoader(TensorDataset(torch.FloatTensor(X_train), torch.FloatTensor(y_train)), shuffle=True, batch_size=BATCH_SIZE)
test_loader = DataLoader(TensorDataset(torch.FloatTensor(X_test), torch.FloatTensor(y_test)), shuffle=False, batch_size=BATCH_SIZE)

# Train
model = LSTMModel(len(features), HIDDEN_SIZE, NUM_LAYERS)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)

print("Training LSTM...")
losses = []
for epoch in range(EPOCHS):
    model.train()
    epoch_loss = 0
    for X_batch, y_batch in train_loader:
        optimizer.zero_grad()
        outputs = model(X_batch).squeeze()
        loss = criterion(outputs, y_batch)
        loss.backward()
        optimizer.step()
        epoch_loss += loss.item()
    avg_loss = epoch_loss / len(train_loader)
    losses.append(avg_loss)
    if (epoch+1) % 10 == 0:
        print(f'Epoch [{epoch+1}/{EPOCHS}], Loss: {avg_loss:.4f}')

# PLOT 1: Training Loss
plt.figure(figsize=(10, 5))
plt.plot(losses)
plt.title('LSTM Training Loss')
plt.xlabel('Epoch')
plt.ylabel('MSE Loss')
plt.grid(True)
plt.savefig(os.path.join(OUTPUT_DIR, '02_training_loss.png'))
plt.close()

# Evaluate
print("Evaluating...")
model.eval()
preds, actuals = [], []
with torch.no_grad():
    for X_batch, y_batch in test_loader:
        preds.extend(model(X_batch).squeeze().numpy())
        actuals.extend(y_batch.numpy())

# Inverse Transform
def inverse_target(scaled_target, scaler):
    dummy = np.zeros((len(scaled_target), len(features)))
    dummy[:, 0] = scaled_target
    return scaler.inverse_transform(dummy)[:, 0]

y_pred_real = inverse_target(preds, scaler)
y_test_real = inverse_target(actuals, scaler)

mae = mean_absolute_error(y_test_real, y_pred_real)
rmse = np.sqrt(mean_squared_error(y_test_real, y_pred_real))
r2 = r2_score(y_test_real, y_pred_real)

print(f"Test MAE: {mae:.4f} kW")
print(f"Test RMSE: {rmse:.4f} kW")
print(f"Test R2: {r2:.4f}")

# PLOT 2: Forecast Sample (First 200 Hours)
plt.figure(figsize=(12, 6))
plt.plot(y_test_real[:200], label='Actual Load', alpha=0.7)
plt.plot(y_pred_real[:200], label='Predicted Load', alpha=0.7)
plt.title('Hourly Load Forecast (Test Set Sample: 200 Hours)')
plt.xlabel('Time (Hours)')
plt.ylabel('Load (kW)')
plt.legend()
plt.savefig(os.path.join(OUTPUT_DIR, '02_forecast_sample.png'))
plt.close()

# PLOT 3: Actual vs Predicted Scatter
plt.figure(figsize=(8, 8))
plt.scatter(y_test_real, y_pred_real, alpha=0.1, s=1)
plt.plot([y_test_real.min(), y_test_real.max()], [y_test_real.min(), y_test_real.max()], 'r--', lw=2)
plt.title('Actual vs Predicted Load')
plt.xlabel('Actual Load (kW)')
plt.ylabel('Predicted Load (kW)')
plt.savefig(os.path.join(OUTPUT_DIR, '02_actual_vs_pred.png'))
plt.close()

# PLOT 4: Residuals Distribution
residuals = y_test_real - y_pred_real
plt.figure(figsize=(10, 5))
sns.histplot(residuals, bins=50, kde=True, color='purple')
plt.title('Distribution of Prediction Residuals')
plt.xlabel('Residual (Actual - Predicted) [kW]')
plt.savefig(os.path.join(OUTPUT_DIR, '02_residuals.png'))
plt.close()

print("Analysis Complete. Figures saved.")