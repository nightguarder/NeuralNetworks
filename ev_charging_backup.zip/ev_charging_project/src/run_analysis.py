import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Config
DATA_DIR = 'ev_charging_project/data'
OUTPUT_DIR = 'ev_charging_project/figures'
os.makedirs(OUTPUT_DIR, exist_ok=True)

FILE_SESSIONS = os.path.join(DATA_DIR, 'Dataset 1_EV charging reports.csv')
FILE_HOURLY = os.path.join(DATA_DIR, 'Dataset_2_Hourly_EV_per_user.csv')
FILE_WEATHER = os.path.join(DATA_DIR, 'Norway_Trondheim_ExactLoc_Weather.csv')

def load_csv(path, sep=';', decimal=','):
    try:
        return pd.read_csv(path, sep=sep, decimal=decimal)
    except Exception as e:
        print(f"Error loading {path}: {e}")
        return None

print("--- 1. Data Loading ---")
df_sessions = load_csv(FILE_SESSIONS)
df_hourly = load_csv(FILE_HOURLY)
df_weather = load_csv(FILE_WEATHER, sep=',', decimal='.')

print("--- 2. Cleaning Session Data ---")
if df_sessions is not None:
    df_sessions.rename(columns={'Start_plugin': 'start_time', 'End_plugout': 'end_time', 'El_kWh': 'energy_kwh', 'Duration_hours': 'duration_hours'}, inplace=True)
    df_sessions['start_time'] = pd.to_datetime(df_sessions['start_time'], format='%d.%m.%Y %H:%M', errors='coerce')
    df_sessions['end_time'] = pd.to_datetime(df_sessions['end_time'], format='%d.%m.%Y %H:%M', errors='coerce')
    df_sessions['duration_hours'] = (df_sessions['end_time'] - df_sessions['start_time']).dt.total_seconds() / 3600.0
    
    # Outliers
    df_clean = df_sessions[(df_sessions['duration_hours'] > 0) & (df_sessions['duration_hours'] <= 200)]
    
    # PLOT 1: Duration Distribution
    plt.figure(figsize=(10, 5))
    sns.histplot(df_clean['duration_hours'], bins=50, kde=True, color='teal')
    plt.title('Distribution of Charging Session Duration')
    plt.xlabel('Duration (Hours)')
    plt.savefig(os.path.join(OUTPUT_DIR, '01_duration_distribution.png'))
    plt.close()
    print("Saved: 01_duration_distribution.png")

print("\n--- 3. Cleaning Hourly Data ---")
if df_hourly is not None:
    df_hourly['datetime'] = pd.to_datetime(df_hourly['date_from'], format='%d.%m.%Y %H:%M', errors='coerce')
    load_cols = [c for c in df_hourly.columns if 'kW' in c]
    df_hourly[load_cols] = df_hourly[load_cols].fillna(0)
    df_hourly['total_load'] = df_hourly[load_cols].sum(axis=1)
    
    # PLOT 2: Hourly Load
    plt.figure(figsize=(12, 5))
    plt.plot(df_hourly['datetime'], df_hourly['total_load'], linewidth=0.5, alpha=0.7)
    plt.title('Hourly Aggregate Charging Load')
    plt.xlabel('Time')
    plt.ylabel('Total Load (kW)')
    plt.savefig(os.path.join(OUTPUT_DIR, '01_hourly_load.png'))
    plt.close()
    print("Saved: 01_hourly_load.png")

print("\n--- 4. Correlation Analysis ---")
if df_hourly is not None and df_weather is not None:
    df_weather['date'] = pd.to_datetime(df_weather['datetime']).dt.date
    weather_cols = ['date', 'temp', 'solar_rad']
    df_weather_clean = df_weather[weather_cols].fillna(0)
    
    daily_load = df_hourly.groupby(df_hourly['datetime'].dt.date)['total_load'].mean().reset_index()
    daily_load.columns = ['date', 'daily_avg_load']
    
    merged = pd.merge(daily_load, df_weather_clean, on='date', how='inner')
    
    # PLOT 3: Correlation Heatmap
    plt.figure(figsize=(6, 5))
    corr_matrix = merged[['daily_avg_load', 'temp', 'solar_rad']].corr()
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f")
    plt.title('Correlation: Load vs Weather')
    plt.savefig(os.path.join(OUTPUT_DIR, '01_correlation_heatmap.png'))
    plt.close()
    print("Saved: 01_correlation_heatmap.png")