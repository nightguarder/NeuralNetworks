# EV Charging Project: Analysis & Modeling Results

## 1. Executive Summary

This report documents the data analysis and deep learning modeling performed to predict Electric Vehicle (EV) charging loads in Trondheim. We analyzed charging session reports and hourly aggregate loads, determining that the hourly aggregate load was the most viable target for modeling. A Multivariate LSTM (Long Short-Term Memory) network was trained to predict future loads based on historical load, traffic, and weather data.

## 2. Data Analysis

**Objective:** Understand the data characteristics and select the optimal target variable.

### 2.1 Data Cleaning & Exploration

- **Session Data:** Outliers (sessions > 200 hours or <= 0 hours) were removed. The distribution of session durations is highly skewed.
- **Hourly Load:** Imputed missing values with 0. This dataset shows clear daily and weekly seasonality.

### 2.2 Key Visualizations

**Session Duration Distribution**
![Duration Distribution](figures/01_duration_distribution.png)
_The distribution of charging durations is right-skewed, indicating most sessions are short, with a long tail of overnight or long-stay charges._

**Hourly Aggregate Load**
![Hourly Load](figures/01_hourly_load.png)
_The hourly aggregate load shows distinct cyclical patterns, making it a suitable candidate for time-series forecasting._

### 2.3 Correlation Analysis

We examined the relationship between external factors (Weather) and the Load.

**Correlation Heatmap**
![Correlation Heatmap](figures/01_correlation_heatmap.png)

- There is a positive correlation between `daily_avg_load` and `solar_rad` / `temp`, though it is relatively weak.
- This confirms that while weather impacts charging (likely due to EV battery efficiency or user travel patterns), it is not the sole driver.

**Decision:** Proceed with **Hourly Aggregate Load** as the prediction target.

---

## 3. LSTM Modeling

**Objective:** Predict the next hour's total charging load using a look-back window of 24 hours.

### 3.1 Model Architecture

- **Type:** Multivariate LSTM
- **Input Features:** `[total_load, total_traffic, temp, solar_rad, hour_sin, hour_cos]`
- **Hidden Layers:** 2 Layers, 64 Units each
- **Sequence Length:** 24 hours
- **Optimizer:** Adam (`lr=0.001`)

### 3.2 Training Performance

The model was trained for 50 epochs.

**Training Loss (MSE)**
![Training Loss](figures/02_training_loss.png)
_The training loss decreases rapidly and stabilizes around 0.02, indicating the model has learned the general trend of the data._

### 3.3 Model Evaluation

The model was evaluated on the test set (last 20% of data).

**Performance Metrics:**

- **Mean Absolute Error (MAE):** 1.4200 kW
- **Root Mean Squared Error (RMSE):** 2.3550 kW
- **R-Squared (R2):** 0.0988

**Forecast Sample (First 200 Test Hours)**
![Forecast Sample](figures/02_forecast_sample.png)
_The model captures the periodicity (peaks and troughs) but struggles with the magnitude of the peaks, leading to underestimation of high loads._

### 3.4 Detailed Error Analysis

**Actual vs. Predicted**
![Actual vs Predicted](figures/02_actual_vs_pred.png)
_Ideally, points should lie on the red diagonal. The scatter shows a "blob" structure, indicating the model predicts near the mean often and fails to capture extreme high/low values effectively._

**Residual Distribution**
![Residuals](figures/02_residuals.png)
_The residuals are roughly normally distributed but centered slightly off-zero, confirming the bias observed in the forecast plot._

## 4. Improved Modeling: GRU with Feature Engineering

**Objective:** Enhance prediction accuracy by capturing weekly seasonality and using a more efficient architecture.

### 4.1 Enhancements
*   **Model:** GRU (Gated Recurrent Unit) - 2 Layers, 128 Units, Dropout 0.2.
*   **Context:** Increased Sequence Length from 24h to 168h (1 Week).
*   **Features:** Added Lag features (`t-24`, `t-168`) and Day-of-Week embeddings (`day_sin`, `day_cos`).

### 4.2 Results
The improved model was trained for 30 epochs.

**Training Loss (MSE)**
![GRU Training Loss](figures/03_training_loss_gru.png)
_Loss converged similarly to the LSTM model._

**Performance Metrics:**
*   **MAE:** 1.7070 kW
*   **RMSE:** 2.3921 kW
*   **R2:** 0.0665

**Forecast Sample (First 300 Test Hours)**
![GRU Forecast](figures/03_forecast_gru.png)
_The GRU model follows the trend but still exhibits bias in amplitude prediction._

### 4.3 Comparison & Conclusion
Contrary to expectations, increasing complexity (GRU + 1-week context) did not immediately yield better results than the simpler LSTM baseline. This suggests that:
1.  **Data Limitation:** The noise in the hourly load data might be dominant, making precise peak prediction difficult regardless of model complexity.
2.  **Overfitting/Optimization:** The larger model might require more careful regularization or a different learning rate schedule.

**Next Steps:**
*   Simplify the feature set (remove potentially noisy lags).
*   Try non-sequential models like XGBoost for comparison.